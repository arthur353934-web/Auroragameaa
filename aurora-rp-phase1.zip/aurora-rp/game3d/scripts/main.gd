extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
var player: CharacterBody3D
var camera_pivot: Node3D
var camera: Camera3D
var move_flags := {"forward": false, "back": false, "left": false, "right": false, "jump": false}
var camera_yaw := 0.0
var camera_pitch := -0.22
var touch_look_id := -1

func _ready() -> void:
	_build_world()
	_build_player()
	_build_camera()
	_build_hud()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.88)
	env.ambient_light_energy = 0.8
	world_env.environment = env
	add_child(world_env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.15
	add_child(sun)
	_add_box("Ground", Vector3(0, -0.25, 0), Vector3(180, 0.5, 180), Color("66845b"))
	# Main roads form a small walkable city block.
	_add_box("Main road", Vector3(0, 0.02, 0), Vector3(15, 0.08, 150), Color("30343a"))
	_add_box("Cross road", Vector3(0, 0.03, 0), Vector3(150, 0.08, 15), Color("30343a"))
	for i in range(-6, 7):
		_add_box("Road marking", Vector3(0, 0.085, i * 10), Vector3(0.35, 0.025, 4.2), Color("f5e6a8"))
		_add_box("Road marking", Vector3(i * 10, 0.085, 0), Vector3(4.2, 0.025, 0.35), Color("f5e6a8"))
	# Procedural buildings around the central intersection.
	var palette: Array[Color] = [Color("b8a18a"), Color("8fa3ad"), Color("d0c2a8"), Color("a5a08f"), Color("8d9b83")]
	var spots := [Vector2(-24,-24), Vector2(24,-24), Vector2(-24,24), Vector2(24,24), Vector2(-48,-12), Vector2(48,12), Vector2(-12,-48), Vector2(12,48)]
	for i in range(spots.size()):
		var h := 7.0 + float((i * 7) % 5) * 2.3
		_add_box("Building %02d" % i, Vector3(spots[i].x, h * 0.5, spots[i].y), Vector3(11, h, 11), palette[i % palette.size()])
		_add_box("Roof %02d" % i, Vector3(spots[i].x, h + 0.15, spots[i].y), Vector3(11.4, 0.3, 11.4), Color("454b50"))
		# Front windows.
		for row in range(1, 3):
			for col in range(2):
				_add_box("Window", Vector3(spots[i].x - 2.5 + col * 5.0, row * 2.4, spots[i].y - 5.56), Vector3(2.0, 1.3, 0.08), Color("83b8cc"))
	# Decorative trees in the park corners.
	for p in [Vector3(-38,0,-38), Vector3(38,0,-38), Vector3(-38,0,38), Vector3(38,0,38)]:
		_add_box("Tree trunk", p + Vector3(0,1.3,0), Vector3(0.7,2.6,0.7), Color("6c4930"))
		_add_sphere("Tree crown", p + Vector3(0,3.4,0), 2.0, Color("3d7845"))

func _add_box(label: String, pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = label
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9
	mesh.material_override = mat
	body.add_child(mesh)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_sphere(label: String, pos: Vector3, radius: float, color: Color) -> void:
	var mesh := MeshInstance3D.new()
	mesh.name = label
	mesh.position = pos
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	mesh.mesh = sphere
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material_override = mat
	add_child(mesh)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 1.2, 5)
	player.set_script(PLAYER_SCRIPT)
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	var visual := MeshInstance3D.new()
	visual.name = "BodyVisual"
	visual.mesh = capsule
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("e0a36b")
	visual.material_override = mat
	player.add_child(visual)
	var shape_node := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.8
	shape_node.shape = shape
	player.add_child(shape_node)
	add_child(player)

func _build_camera() -> void:
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0, 1.3, 0)
	player.add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 3.2, 7.5)
	camera.look_at(Vector3.ZERO)
	camera.current = true
	camera_pivot.add_child(camera)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var title := Label.new()
	title.text = "AURORA RP  |  PROTÓTIPO 3D"
	title.position = Vector2(24, 18)
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color.WHITE)
	layer.add_child(title)
	var hint := Label.new()
	hint.text = "Explore a cidade • Arraste o lado direito para girar a câmera"
	hint.position = Vector2(24, 50)
	hint.add_theme_font_size_override("font_size", 15)
	hint.add_theme_color_override("font_color", Color("e8edf2"))
	layer.add_child(hint)
	_add_touch_button(layer, "▲", Vector2(34, -178), "forward")
	_add_touch_button(layer, "▼", Vector2(34, -82), "back")
	_add_touch_button(layer, "◀", Vector2( -14, -130), "left")
	_add_touch_button(layer, "▶", Vector2(82, -130), "right")
	_add_touch_button(layer, "PULAR", Vector2(-142, -112), "jump", true)
	var footer := Label.new()
	footer.text = "WASD / setas: mover   •   Espaço: pular"
	footer.position = Vector2(24, -34)
	footer.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	footer.add_theme_color_override("font_color", Color.WHITE)
	layer.add_child(footer)

func _add_touch_button(layer: CanvasLayer, caption: String, offset: Vector2, action: String, wide := false) -> void:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size = Vector2(92 if wide else 68, 68)
	var view_size := get_viewport().get_visible_rect().size
	if action == "jump":
		b.position = Vector2(view_size.x - 116, view_size.y - 126)
	else:
		b.position = Vector2(24 + offset.x, view_size.y + offset.y)
	b.modulate = Color(1, 1, 1, 0.78)
	b.add_theme_font_size_override("font_size", 19)
	layer.add_child(b)
	b.button_down.connect(func(): move_flags[action] = true)
	b.button_up.connect(func(): move_flags[action] = false)

func _physics_process(_delta: float) -> void:
	if is_instance_valid(player):
		player.set("mobile_input", Vector2(float(move_flags.right) - float(move_flags.left), float(move_flags.back) - float(move_flags.forward)))
		player.set("mobile_jump", move_flags.jump)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x * 0.48:
			touch_look_id = event.index
		elif not event.pressed and event.index == touch_look_id:
			touch_look_id = -1
	elif event is InputEventScreenDrag and event.index == touch_look_id:
		camera_yaw -= event.relative.x * 0.004
		camera_pitch = clamp(camera_pitch - event.relative.y * 0.003, -0.75, 0.18)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		camera_yaw -= event.relative.x * 0.004
		camera_pitch = clamp(camera_pitch - event.relative.y * 0.003, -0.75, 0.18)
	camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0)
