extends CharacterBody3D

@export var speed := 6.0
@export var jump_velocity := 5.0
var mobile_input := Vector2.ZERO
var mobile_jump := false
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	var axis := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if mobile_input.length() > 0.05:
		axis = mobile_input.normalized()
	var direction := Vector3(axis.x, 0, axis.y)
	# Camera-relative movement is calculated from the camera pivot rotation.
	var yaw := 0.0
	var cam := get_viewport().get_camera_3d()
	if cam != null:
		yaw = cam.global_rotation.y
	direction = direction.rotated(Vector3.UP, yaw)
	if direction.length() > 0.05:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), delta * 10.0)
	else:
		velocity.x = move_toward(velocity.x, 0, speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0, speed * 5.0 * delta)
	if (Input.is_action_just_pressed("jump") or mobile_jump) and is_on_floor():
		velocity.y = jump_velocity
	move_and_slide()
