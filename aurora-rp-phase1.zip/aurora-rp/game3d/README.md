# Aurora RP Mobile — protótipo 3D (Fase 1)

Este é o primeiro protótipo jogável do Aurora RP Mobile, feito em Godot 4. Ele cria uma pequena cidade 3D procedural, personagem em terceira pessoa, colisões, câmera e controles por teclado/toque.

## Estado real desta versão
- Inclui: cenário 3D inicial, personagem, movimentação, pulo, câmera giratória e botões de toque.
- Ainda não inclui: multiplayer, veículos, missões, economia, persistência de personagens ou conexão funcional com FiveM. Esses sistemas serão fases posteriores.
- O APK Android precisa ser compilado pelo workflow do GitHub com os templates/exportação Android do Godot configurados.

## Testar no computador
Abra esta pasta no Godot 4.3 ou superior e pressione F6/F5.

## Controles
- PC: WASD ou setas para andar; Espaço para pular; botão direito do mouse + arrastar para girar a câmera.
- Android: setas na tela para andar; PULAR; arraste o lado direito da tela para girar a câmera.

## Próxima fase
Adicionar veículo dirigível e primeira missão, depois preparar a camada de rede para multiplayer e autenticação compartilhada com o backend Aurora.
